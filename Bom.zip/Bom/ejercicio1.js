/*
En una nueva ventana, imprimir todas las 
propiedades del objeto navigator.
*/

// Abre una nueva ventana
let nuevaVentana = window.open("", "Propiedades de Navigator", "width=600,height=400");

// Obtiene todas las propiedades del objeto navigator
//let propiedades = Object.keys(navigator);

// Crea una cadena con todas las propiedades
//let contenido = "<h1>Propiedades del objeto Navigator</h1><ul>";
//propiedades.forEach(propiedad => {
//    contenido += `<li>${propiedad}: ${navigator[propiedad]}</li>`;
//});
//contenido += "</ul>";
//
//// Escribe el contenido en la nueva ventana
//nuevaVentana.document.write(contenido);
//nuevaVentana.document.close();


